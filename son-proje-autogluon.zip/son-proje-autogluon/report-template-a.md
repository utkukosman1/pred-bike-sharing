# Report: Predict Bike Sharing Demand with AutoGluon Solution
#### Kemal Utku Kosman

## Initial Training
### What did you realize when you tried to submit your predictions? What changes were needed to the output of the predictor to submit your results?
TODO: I saw the commands that given were Linux commands. So I had a resarch and changed them into Windows commmands. When I try to submit predictions obtained from all experiments, some of the experiments delivered negative predictions values.
Kaggle refuses the submissions containing negative predictions values obtained from the predictor. Hence, all such negative outputs from respective predictors were replaced with 0.

### What was the top ranked model that performed?
 "WeightedEnsembleL2" model is the best among others.On added features or initial model it was also WeightedEnsembleL3 the best scorer among others.

## Exploratory data analysis and feature creation
### What did the exploratory analysis find and how did you add additional features?
 I added hour feature as extra and I checked DataFrames for checking which feature would be into the EDA.

### How much better did your model preform after adding additional features and why do you think that is?
The addition of features improved model performance approximately  in comparison to the initial/raw model performance.
The model performance improved after converting certain categorical variables with integer data types into their true categorical datatypes.
Adding hour feature, improved the model performance by %62.

## Hyper parameter tuning
### How much better did your model preform after trying different hyper parameters?
 Way more better, this was the first time I experienced AutoGluon and it really suprised me.
The model performance improved after converting certain categorical variables with integer data types into their true categorical datatypes.
But it mat fail on different tasks, because AutoGluon gives algorithms a little bit of time for train.

### If you were given more time with this dataset, where do you think you would spend more time?
 Setting more hyperparameters and trying to get best optimized model.

### Create a table with the models you ran, the hyperparameters modified, and the kaggle score.
|model|hpo1|hpo2|hpo3|score|
|--|--|--|--|--|
|initial|prescribed_values ||prescribed_values |"presets: 'best_quality'"|1.79681
|add_features|prescribed_values|prescribed_values|?|"presets: 'best_quality'"|0.67856
|hpo|gbm|nn_torch|prescribed_values|"presets: 'optimize_for_deployment'"|0.52771

### Create a line plot showing the top model score for the three (or more) training runs during the project.



![model_train_score.png](img/modelscore.png)

### Create a line plot showing the top kaggle score for the three (or more) prediction submissions during the project.


![model_test_score.png](img/kagglescore.png)

## Summary
TI think it was a great exercise, but it can be more spesific and understandable. As a junior, I really tried hard and searched a lot in this project and there was a lot of nodes I've been stucked through. Maybe it is good, but I think for juniors it should be more spesific and understandable.
According to percentage increase, my models performence improvments numeric value is : 70.6307289. That means model performance jumped nearly %70.
Among the models AutoGluon trained, best scorer is WeightedEnsembleL3.

The top-ranked model was the (hpo) model named WeightedEnsemble_L2, with a validation RMSE score of 1.322012(on test dataset)


NOTE: Because I worked with vscode I had a problem to export the notebook with .ipynb extension